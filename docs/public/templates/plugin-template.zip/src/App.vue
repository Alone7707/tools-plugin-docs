<script setup>
defineOptions({ name: 'AToolBoxBlankPlugin' })

defineProps({
  /** Manifest 配置副本。 */
  config: { type: Object, default: () => ({}) },
  /** 打开插件时由宿主传入的文本。 */
  initialText: { type: String, default: '' },
  /** 当前进入动作。 */
  enterAction: { type: Object, default: null },
  /** 宿主公开插件 API。 */
  api: { type: Object, default: null }
})
</script>

<template>
  <main class="plugin-template">
    <h1>开始开发你的插件</h1>
    <p>在 src/App.vue 中编写界面，在 src 目录中拆分普通 JavaScript 模块和 Vue 组件。</p>
  </main>
</template>

<style scoped>
.plugin-template {
  box-sizing: border-box;
  width: 100%;
  min-height: 100%;
  padding: 24px;
  color: #1f2328;
  background: #ffffff;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}

.plugin-template h1 {
  margin: 0 0 8px;
  font-size: 22px;
}

.plugin-template p {
  margin: 0;
  color: #667085;
  line-height: 1.7;
}
</style>
