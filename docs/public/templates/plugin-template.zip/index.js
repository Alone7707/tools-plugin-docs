/**
 * AToolBox 空白插件入口。
 */

const VueRuntime = window.Vue
// 宿主注入的 Vue 运行时。

if (!VueRuntime) throw new Error('[blank_plugin] 未找到 window.Vue，请通过 AToolBox 客户端加载插件')

const { defineComponent, h } = VueRuntime
// 空白模板使用的 Vue API。

export default defineComponent({
  name: 'AToolBoxBlankPlugin',
  props: {
    /** Manifest 配置副本。 */
    config: { type: Object, default: () => ({}) },
    /** 打开插件时由宿主传入的文本。 */
    initialText: { type: String, default: '' },
    /** 当前进入动作。 */
    enterAction: { type: Object, default: null },
    /** 宿主公开插件 API。 */
    api: { type: Object, default: null }
  },
  /** 初始化空白插件组件。 */
  setup() {
    return () => h('main', { class: 'blank-plugin' })
  }
})
