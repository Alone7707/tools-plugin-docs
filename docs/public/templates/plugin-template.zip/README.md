# ToolZen 空白插件模板

该目录是基于 Vue 3 SFC 与 Vite 的最小插件工程，不包含业务功能和 API 示例。

## 文件

```text
plugin-template/
  package.json
  vite.config.js
  manifest.json
  src/
    App.vue
    main.js
  dist/
    manifest.json
    index.js
  README.md
```

- 修改 `manifest.json` 中的 `code`、`name`、描述、关键词和功能入口。
- 在 `src/App.vue` 中开发界面，可在 `src` 下继续拆分 `.vue` 和 `.js` 文件。
- 需要宿主能力时通过 `api` prop 调用，完整示例见相邻目录 `plugin-api-example`。
- `pnpm dev` 会持续构建，`pnpm build` 会生成一次正式产物。
- 客户端选择和后台上传都使用 `dist` 目录。
- Vue 依赖只用于开发和 SFC 编译，构建产物继续使用宿主提供的 `window.Vue`。

开发文档：[ToolZen 插件开发文档](https://docs.a-tools.cc.cd/)
