# AToolBox 空白插件模板

该目录是最小可运行插件骨架，不包含业务功能和 API 示例。

## 文件

```text
plugin-template/
  manifest.json
  index.js
  README.md
```

- 修改 `manifest.json` 中的 `code`、`name`、描述、关键词和功能入口。
- 在 `index.js` 的 `setup` 中实现插件界面与逻辑。
- 需要宿主能力时通过 `api` prop 调用，完整示例见相邻目录 `plugin-api-example`。
- 使用宿主提供的 `window.Vue`，入口保持原生 ESM，不使用 Node.js、`require` 或 Electron 内部 IPC。

开发文档：[AToolBox 插件开发文档](https://docs.a-tools.cc.cd/)
