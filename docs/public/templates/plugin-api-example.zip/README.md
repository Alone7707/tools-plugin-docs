# AToolBox 全量插件 API 示例

该目录只用于演示 AToolBox 向第三方插件公开的能力，不包含文本编辑器、统计工具或其他业务功能。

开发文档中的“Electron Bridge 完整清单”包含账号、更新、商店、开发者专区、内部窗口等宿主内部通道；第三方插件模板只覆盖通过 `api` prop 稳定公开的能力，不直接调用 `window.atoolbox`。

## 文件

```text
plugin-api-example/
  manifest.json
  index.js
  README.md
```

- `index.js`：按文档分类展示全部运行时 API，每个能力都有独立调用入口和返回结果。
- `manifest.json`：演示权限、`features[].cmds`、`clipboardRules` 和进入动作。

## 调试

在客户端打开“开发者专区”，选择本目录。修改代码后点击“重新加载”，再打开插件即可看到变化。

入口是原生 ESM：不能包含 TypeScript 语法，不能使用 Node.js、`require`、`fs` 或 Electron 内部 IPC。
Vue 运行时必须使用宿主提供的 `window.Vue`。

## 能力清单

### 事件

- `getEnterAction`
- `onPluginEnter`
- `onPluginOut`
- `onPluginDetach`
- `onThemeChange`
- `onWindowShow`
- `onWindowHide`

### 窗口

- `hideMainWindow`
- `showMainWindow`
- `outPlugin`
- `detachWindow`
- `setExpendHeight`
- `isDetachedWindow`
- `getWindowType`
- `redirect`
- `setSubtitle`
- `setDetachPayload`
- `isDarkColors`

### 剪贴板

- `copyText`
- `readClipboardText`
- `readClipboardImage`
- `clearClipboard`
- `copyClipboardImage`

### 输入与动态指令

- `initialText`
- `enterAction`
- `features[].cmds`：字符串、`regex`、`over`、`img`
- `clipboardRules`：`json`、`regex`、`url`、`timestamp`、`color`、`image`

### 系统

- `showNotification`
- `showOpenDialog`
- `showSaveDialog`
- `shellBeep`
- `shellOpenExternal`
- `getAppName`
- `getAppVersion`
- `getPlatform`
- `isDev`
- `isMacOS`
- `isWindows`
- `isLinux`

### 屏幕

- `screenColorPick`
- `getPrimaryDisplay`
- `getAllDisplays`
- `getCursorScreenPoint`
- `getDisplayNearestPoint`
- `getDisplayMatching`
- `screenToDipPoint`
- `dipToScreenPoint`
- `screenToDipRect`
- `dipToScreenRect`

### 插件身份

- `pluginCode`
- `getPluginInfo`
- `getPluginConfig`

第三方插件不开放用户账号、令牌或个人资料读取能力。

### 数据存储

- `db.get`
- `db.put`
- `db.remove`
- `dbStorage.getItem`
- `dbStorage.setItem`
- `dbStorage.removeItem`

剪贴板读写需要 `clipboard:read` / `clipboard:write`，文件对话框需要 `file:dialog`。模板已在 Manifest 中声明这些权限。

完整说明：[AToolBox 插件开发文档](https://docs.a-tools.cc.cd/)
