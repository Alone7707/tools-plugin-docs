<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'

const DEFAULT_TEXT = 'ToolZen 插件 API 示例'
// 示例 API 使用的默认文本。
const DOCS_URL = 'https://docs.toolzen.top/'
// 插件开发文档地址。
const REDIRECT_PLUGIN_CODE = 'encoding_assistant'
// 跨插件跳转示例使用的目标插件编码。

defineOptions({ name: 'ToolZenPluginApiExample' })

const props = defineProps({
  /** Manifest 配置副本。 */
  config: { type: Object, default: () => ({}) },
  /** 打开插件时由宿主传入的文本。 */
  initialText: { type: String, default: '' },
  /** 当前进入动作。 */
  enterAction: { type: Object, default: null },
  /** 宿主公开插件 API。 */
  api: { type: Object, default: null }
})
// 宿主传入的插件运行参数。
const result = ref('点击任意能力查看返回结果。事件 API 已自动注册。')
// 最近一次 API 调用或事件结果。
const resultTitle = ref('API 返回结果')
// 结果区域标题。
const isDark = ref(Boolean(props.api?.isDarkColors?.()))
// 当前宿主是否使用深色主题。
const clipboardImage = ref('')
// 最近读取到的剪贴板图片 Data URL。
const cleanupCallbacks = []
// 事件监听取消函数集合。
const sampleText = computed(() => String(props.initialText || DEFAULT_TEXT))
// 示例 API 使用的文本。

/** 把 API 返回值格式化为可读文本。 */
function formatResult(value) {
  if (typeof value === 'string') return value || '(空字符串)'
  if (value === undefined) return '(undefined)'
  try {
    return JSON.stringify(value, null, 2)
  } catch {
    return String(value)
  }
}

/** 创建一个 API 示例按钮描述。 */
function createAction(name, description, run) {
  return { name, description, run }
}

/** 显示 API 调用或事件结果。 */
function showResult(title, value) {
  resultTitle.value = title
  result.value = formatResult(value)
}

/** 执行 API 示例并捕获异常。 */
async function runExample(name, callback) {
  if (!props.api) {
    showResult(name, '当前环境未提供 api prop')
    return
  }
  try {
    const value = await callback()
    // 当前 API 返回值。
    showResult(name, value)
  } catch (error) {
    showResult(name, error instanceof Error ? error.message : String(error))
  }
}

/** 读取剪贴板图片并保存给 copyClipboardImage 示例。 */
async function readClipboardImage() {
  const value = await props.api.readClipboardImage()
  // 系统剪贴板图片 Data URL。
  clipboardImage.value = value
  return value ? `已读取图片 Data URL，长度 ${value.length}` : '剪贴板没有图片'
}

/** 把最近读取的图片重新写入剪贴板。 */
async function copyClipboardImage() {
  if (!clipboardImage.value) return '请先调用 readClipboardImage'
  return props.api.copyClipboardImage(clipboardImage.value)
}

/** 写入 db 示例文档。 */
function putDbValue() {
  return props.api.db.put('api-example', { text: sampleText.value, savedAt: Date.now() })
}

/** 写入 dbStorage 示例字符串。 */
function setDbStorageValue() {
  props.api.dbStorage.setItem('api-example', sampleText.value)
  return true
}

/** 读取距离鼠标最近的显示器。 */
async function getDisplayNearestPoint() {
  const point = await props.api.getCursorScreenPoint()
  // 当前鼠标屏幕坐标。
  return props.api.getDisplayNearestPoint(point)
}

/** 读取与主显示器矩形匹配的显示器。 */
async function getDisplayMatching() {
  const display = await props.api.getPrimaryDisplay()
  // 主显示器信息。
  return props.api.getDisplayMatching(display.bounds)
}

/** 把当前鼠标像素坐标转换为 DIP。 */
async function screenToDipPoint() {
  const point = await props.api.getCursorScreenPoint()
  // 当前鼠标屏幕坐标。
  return props.api.screenToDipPoint(point)
}

/** 把主显示器像素矩形转换为 DIP。 */
async function screenToDipRect() {
  const display = await props.api.getPrimaryDisplay()
  // 主显示器信息。
  return props.api.screenToDipRect(display.bounds)
}

/** 注册一个宿主事件并保存取消函数。 */
function bindEvent(name, register, callback) {
  if (typeof register !== 'function') return
  const cleanup = register((payload) => {
    callback(payload)
    showResult(name, payload === undefined ? '事件已触发' : payload)
  })
  // 当前事件的取消监听函数。
  if (typeof cleanup === 'function') cleanupCallbacks.push(cleanup)
}

const groups = computed(() => [
  {
    title: '事件',
    actions: [
      createAction('getEnterAction', '读取当前进入动作', () => props.api.getEnterAction()),
      createAction('onPluginEnter', '已自动注册进入事件', () => '已注册，重新进入插件时触发'),
      createAction('onPluginOut', '已自动注册退出事件', () => '已注册，退出插件时触发'),
      createAction('onPluginDetach', '已自动注册分离事件', () => '已注册，分离窗口时触发'),
      createAction('onThemeChange', '已自动注册主题事件', () => `已注册，当前主题 ${isDark.value ? 'dark' : 'light'}`),
      createAction('onWindowShow', '已自动注册显示事件', () => '已注册，显示主窗口时触发'),
      createAction('onWindowHide', '已自动注册隐藏事件', () => '已注册，隐藏主窗口时触发')
    ]
  },
  {
    title: '窗口',
    actions: [
      createAction('hideMainWindow', '隐藏主窗口', () => props.api.hideMainWindow()),
      createAction('showMainWindow', '显示并聚焦主窗口', () => props.api.showMainWindow()),
      createAction('outPlugin', '退出当前插件', () => props.api.outPlugin()),
      createAction('detachWindow', '分离为独立窗口', () => props.api.detachWindow({ title: '插件 API 示例', width: 760, height: 680 })),
      createAction('setExpendHeight', '调整主窗口高度', () => props.api.setExpendHeight(640, { minimumHeight: 420, animate: true, durationMs: 180 })),
      createAction('isDetachedWindow', '判断是否为独立窗口', () => props.api.isDetachedWindow()),
      createAction('getWindowType', '读取窗口类型', () => props.api.getWindowType()),
      createAction('redirect', '跳转到编码助手', () => props.api.redirect(REDIRECT_PLUGIN_CODE, sampleText.value)),
      createAction('setSubtitle', '设置宿主标题栏副标题', () => props.api.setSubtitle('API 示例')),
      createAction('setDetachPayload', '设置分离窗口载荷', () => props.api.setDetachPayload(() => ({ initialText: sampleText.value, width: 760, height: 680 }))),
      createAction('isDarkColors', '读取当前深色主题状态', () => props.api.isDarkColors())
    ]
  },
  {
    title: '复制',
    actions: [
      createAction('copyText', '复制示例文本', () => props.api.copyText(sampleText.value)),
      createAction('readClipboardText', '读取剪贴板文本', () => props.api.readClipboardText()),
      createAction('readClipboardImage', '读取剪贴板图片', readClipboardImage),
      createAction('clearClipboard', '清空剪贴板', () => props.api.clearClipboard()),
      createAction('copyClipboardImage', '复制最近读取的图片', copyClipboardImage)
    ]
  },
  {
    title: '输入与动态指令',
    actions: [
      createAction('initialText', '读取组件 initialText prop', () => props.initialText),
      createAction('enterAction', '读取组件 enterAction prop', () => props.enterAction),
      createAction('features[].cmds', '查看 Manifest 指令示例', () => ['字符串', 'regex', 'over', 'img']),
      createAction('clipboardRules', '查看 Manifest 剪贴板规则', () => ['json', 'regex', 'url', 'timestamp', 'color', 'image'])
    ]
  },
  {
    title: '系统',
    actions: [
      createAction('toast', '显示主应用 Toast', () => props.api.toast('插件 Toast 示例', 3000)),
      createAction('showNotification', '发送系统通知', () => props.api.showNotification('插件 API 示例通知', 'ToolZen')),
      createAction('showOpenDialog', '打开文件选择对话框', () => props.api.showOpenDialog({ title: '选择文件', properties: ['openFile', 'multiSelections'] })),
      createAction('showSaveDialog', '打开文件保存对话框', () => props.api.showSaveDialog({ title: '选择保存位置', defaultPath: 'toolzen-api-example.txt' })),
      createAction('shellBeep', '播放系统提示音', () => props.api.shellBeep()),
      createAction('shellOpenExternal', '在浏览器打开开发文档', () => props.api.shellOpenExternal(DOCS_URL)),
      createAction('getAppName', '读取宿主应用名称', () => props.api.getAppName()),
      createAction('getAppVersion', '读取宿主应用版本', () => props.api.getAppVersion()),
      createAction('getPlatform', '读取 Electron 平台标识', () => props.api.getPlatform()),
      createAction('isDev', '判断是否为本地调试插件', () => props.api.isDev()),
      createAction('isMacOS', '判断当前系统是否为 macOS', () => props.api.isMacOS()),
      createAction('isWindows', '判断当前系统是否为 Windows', () => props.api.isWindows()),
      createAction('isLinux', '判断当前系统是否为 Linux', () => props.api.isLinux())
    ]
  },
  {
    title: '屏幕',
    actions: [
      createAction('screenColorPick', '调用全屏取色器', () => props.api.screenColorPick()),
      createAction('getPrimaryDisplay', '读取主显示器信息', () => props.api.getPrimaryDisplay()),
      createAction('getAllDisplays', '读取全部显示器信息', () => props.api.getAllDisplays()),
      createAction('getCursorScreenPoint', '读取鼠标屏幕坐标', () => props.api.getCursorScreenPoint()),
      createAction('getDisplayNearestPoint', '读取距离鼠标最近的显示器', getDisplayNearestPoint),
      createAction('getDisplayMatching', '读取匹配指定矩形的显示器', getDisplayMatching),
      createAction('screenToDipPoint', '屏幕像素点转换为 DIP', screenToDipPoint),
      createAction('dipToScreenPoint', 'DIP 点转换为屏幕像素', () => props.api.dipToScreenPoint({ x: 100, y: 100 })),
      createAction('screenToDipRect', '屏幕像素矩形转换为 DIP', screenToDipRect),
      createAction('dipToScreenRect', 'DIP 矩形转换为屏幕像素', () => props.api.dipToScreenRect({ x: 100, y: 100, width: 320, height: 240 }))
    ]
  },
  {
    title: '插件身份',
    actions: [
      createAction('pluginCode', '读取当前插件稳定编码', () => props.api.pluginCode),
      createAction('getPluginInfo', '读取插件身份与运行类型', () => props.api.getPluginInfo()),
      createAction('getPluginConfig', '读取 Manifest 配置副本', () => props.api.getPluginConfig())
    ]
  },
  {
    title: '数据存储',
    actions: [
      createAction('db.put', '写入 JSON 文档', putDbValue),
      createAction('db.get', '读取 JSON 文档', () => props.api.db.get('api-example')),
      createAction('db.remove', '删除 JSON 文档', () => props.api.db.remove('api-example')),
      createAction('dbStorage.setItem', '写入字符串', setDbStorageValue),
      createAction('dbStorage.getItem', '读取字符串', () => props.api.dbStorage.getItem('api-example')),
      createAction('dbStorage.removeItem', '删除字符串', () => props.api.dbStorage.removeItem('api-example'))
    ]
  }
])
// 按文档分类生成的全部公开能力示例。

onMounted(() => {
  if (!props.api) return
  bindEvent('onPluginEnter', props.api.onPluginEnter, () => undefined)
  bindEvent('onPluginOut', props.api.onPluginOut, () => undefined)
  bindEvent('onPluginDetach', props.api.onPluginDetach, () => undefined)
  bindEvent('onThemeChange', props.api.onThemeChange, (theme) => { isDark.value = theme === 'dark' })
  bindEvent('onWindowShow', props.api.onWindowShow, () => undefined)
  bindEvent('onWindowHide', props.api.onWindowHide, () => undefined)
  props.api.setSubtitle?.('API 示例')
  props.api.setDetachPayload?.(() => ({ initialText: sampleText.value, width: 760, height: 680 }))
})

onBeforeUnmount(() => {
  cleanupCallbacks.splice(0).forEach((cleanup) => cleanup())
  props.api?.setDetachPayload?.(null)
})
</script>

<template>
  <main class="plugin-api-example" :class="{ 'is-dark': isDark }">
    <header class="plugin-api-example__header">
      <h1>ToolZen 全量插件 API 示例</h1>
      <p>每个公开能力独立展示。点击方法即可调用，事件能力会在生命周期触发时自动输出结果。</p>
    </header>

    <section class="plugin-api-example__result">
      <strong>{{ resultTitle }}</strong>
      <pre>{{ result }}</pre>
    </section>

    <div class="plugin-api-example__groups">
      <section v-for="group in groups" :key="group.title" class="plugin-api-example__group">
        <h2>{{ group.title }}</h2>
        <div class="plugin-api-example__actions">
          <button
            v-for="item in group.actions"
            :key="item.name"
            class="plugin-api-example__action"
            type="button"
            @click="runExample(item.name, item.run)"
          >
            <code>{{ item.name }}</code>
            <span>{{ item.description }}</span>
          </button>
        </div>
      </section>
    </div>
  </main>
</template>

<style>
.plugin-api-example {
  box-sizing: border-box;
  display: grid;
  grid-template-rows: auto auto minmax(0, 1fr);
  gap: 16px;
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: 18px;
  overflow: hidden;
  color: #1f2328;
  background: #f6f8fa;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  font-size: 13px;
}

.plugin-api-example.is-dark {
  color: #f0f2f5;
  background: #24262b;
}

.plugin-api-example__header {
  display: grid;
  gap: 6px;
}

.plugin-api-example__header h1 {
  margin: 0;
  font-size: 20px;
}

.plugin-api-example__header p {
  margin: 0;
  color: #667085;
  line-height: 1.6;
}

.plugin-api-example.is-dark .plugin-api-example__header p {
  color: #aeb4bf;
}

.plugin-api-example__result,
.plugin-api-example__group {
  display: grid;
  gap: 10px;
  padding: 12px;
  background: #ffffff;
  border: 1px solid #d8dee4;
  border-radius: 8px;
}

.plugin-api-example.is-dark .plugin-api-example__result,
.plugin-api-example.is-dark .plugin-api-example__group {
  background: #303238;
  border-color: #484b53;
}

.plugin-api-example__result strong,
.plugin-api-example__group h2 {
  margin: 0;
  font-size: 14px;
}

.plugin-api-example__result pre {
  min-height: 42px;
  max-height: 180px;
  margin: 0;
  overflow: auto;
  color: #475467;
  font-family: Consolas, "Cascadia Code", monospace;
  font-size: 11px;
  line-height: 1.55;
  white-space: pre-wrap;
  word-break: break-word;
  user-select: text;
}

.plugin-api-example.is-dark .plugin-api-example__result pre {
  color: #c7cad1;
}

.plugin-api-example__groups {
  display: grid;
  gap: 12px;
  min-height: 0;
  padding-right: 4px;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
}

.plugin-api-example__actions {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 8px;
}

.plugin-api-example__action {
  display: grid;
  gap: 3px;
  min-width: 0;
  min-height: 58px;
  padding: 9px 10px;
  color: inherit;
  font: inherit;
  text-align: left;
  background: #f6f8fa;
  border: 1px solid #d8dee4;
  border-radius: 7px;
  cursor: pointer;
}

.plugin-api-example__action:hover {
  border-color: #2f81f7;
}

.plugin-api-example.is-dark .plugin-api-example__action {
  background: #3a3d44;
  border-color: #50545d;
}

.plugin-api-example__action code {
  overflow: hidden;
  color: #0969da;
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.plugin-api-example.is-dark .plugin-api-example__action code {
  color: #72a7ff;
}

.plugin-api-example__action span {
  overflow: hidden;
  color: #667085;
  font-size: 11px;
  line-height: 1.45;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.plugin-api-example.is-dark .plugin-api-example__action span {
  color: #aeb4bf;
}
</style>
