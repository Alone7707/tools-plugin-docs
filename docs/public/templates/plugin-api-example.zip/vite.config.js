import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'
import * as VueExports from 'vue'

const PROJECT_ROOT = fileURLToPath(new URL('.', import.meta.url))
// 当前插件工程根目录。
const MANIFEST_PATH = fileURLToPath(new URL('./manifest.json', import.meta.url))
// 插件清单文件路径。
const README_PATH = fileURLToPath(new URL('./README.md', import.meta.url))
// 插件说明文件路径。
const VIRTUAL_VUE_ID = '\0atoolbox-host-vue'
// 宿主 Vue 运行时虚拟模块标识。
const RESERVED_EXPORT_NAMES = new Set(['default', 'delete', 'in', 'instanceof', 'new', 'typeof', 'void'])
// 不能作为具名导出的 JavaScript 保留字。
const VUE_EXPORT_NAMES = Object.keys(VueExports)
  .filter((name) => /^[$A-Z_a-z][$\w]*$/.test(name) && !RESERVED_EXPORT_NAMES.has(name))
// 可从宿主 window.Vue 转发的 Vue 导出名称。

/** 创建把源码中的 vue 导入映射到宿主 window.Vue 的构建插件。 */
function createHostVuePlugin() {
  return {
    name: 'atoolbox-host-vue',
    enforce: 'pre',
    /** 将 vue 包解析为内部虚拟模块。 */
    resolveId(id) {
      return id === 'vue' ? VIRTUAL_VUE_ID : null
    },
    /** 生成宿主 Vue 运行时的具名导出。 */
    load(id) {
      if (id !== VIRTUAL_VUE_ID) return null
      const exportsSource = VUE_EXPORT_NAMES
        .map((name) => `export const ${name} = VueRuntime.${name}`)
        .join('\n')
      // 按当前 Vue 版本生成的导出语句。
      return `const VueRuntime = window.Vue\n// AToolBox 宿主注入的 Vue 运行时。\nif (!VueRuntime) throw new Error('未找到 window.Vue，请通过 AToolBox 客户端加载插件')\n${exportsSource}\n`
    }
  }
}

/** 创建清单复制与 CSS 内联构建插件。 */
function createPluginPackagePlugin() {
  return {
    name: 'atoolbox-plugin-package',
    enforce: 'post',
    /** 将清单和说明文件加入监听并复制到 dist。 */
    buildStart() {
      this.addWatchFile(MANIFEST_PATH)
      this.addWatchFile(README_PATH)
      this.emitFile({ type: 'asset', fileName: 'manifest.json', source: readFileSync(MANIFEST_PATH) })
      this.emitFile({ type: 'asset', fileName: 'README.md', source: readFileSync(README_PATH) })
    },
    /** 将 Vue SFC 生成的 CSS 注入入口 JS，避免宿主额外加载样式文件。 */
    generateBundle(_options, bundle) {
      const cssEntries = Object.entries(bundle).filter(([, item]) => item.type === 'asset' && item.fileName.endsWith('.css'))
      // 当前构建产生的全部 CSS 资源。
      if (!cssEntries.length) return
      const cssText = cssEntries.map(([, item]) => String(item.source)).join('\n')
      // 合并后的插件样式文本。
      const manifest = JSON.parse(readFileSync(MANIFEST_PATH, 'utf8'))
      // 当前插件清单。
      const styleId = `atoolbox-plugin-style-${manifest.code}`
      // 注入宿主页面的样式节点 ID。
      const entryChunk = Object.values(bundle).find((item) => item.type === 'chunk' && item.isEntry)
      // 插件入口构建产物。
      if (!entryChunk || entryChunk.type !== 'chunk') return
      const styleBootstrap = `if (typeof document !== 'undefined') {\n  const pluginStyleId = ${JSON.stringify(styleId)}\n  // 插件样式节点 ID。\n  let pluginStyle = document.getElementById(pluginStyleId)\n  // 宿主页面中已有的插件样式节点。\n  if (!pluginStyle) {\n    pluginStyle = document.createElement('style')\n    pluginStyle.id = pluginStyleId\n    document.head.appendChild(pluginStyle)\n  }\n  pluginStyle.textContent = ${JSON.stringify(cssText)}\n}\n`
      // 写入入口文件顶部的样式挂载代码。
      entryChunk.code = `${styleBootstrap}\n${entryChunk.code}`
      for (const [fileName] of cssEntries) delete bundle[fileName]
    }
  }
}

export default defineConfig({
  root: PROJECT_ROOT,
  plugins: [createHostVuePlugin(), vue(), createPluginPackagePlugin()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    cssCodeSplit: false,
    minify: false,
    lib: {
      entry: 'src/main.js',
      formats: ['es'],
      fileName: () => 'index.js'
    },
    rollupOptions: {
      output: {
        inlineDynamicImports: true
      }
    }
  }
})
